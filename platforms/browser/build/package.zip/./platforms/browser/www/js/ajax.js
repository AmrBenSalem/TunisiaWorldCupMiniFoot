			// $.ajax({
			//   type: "POST",
			//   url: urlGetInputs,
			//   data: { t: selectedtable }
			// }).done(function( msg ) {
			//   // $("#config").html(msg);
			//   $('#title').val(selectedtable);
			//   $('#title').prop('disabled',true);
			//   $('#commands').val(msg);
			//   $('#commands').prop('disabled',true);
			// });  


// $.ajax({
//     method: 'POST',
//     url: 'http://127.0.0.1/TunisiaWorldCup/php/test.php',
//     dataType: 'text',
//     success: function (data) { 
//     	alert(data); 
//     }
// });

        // function pushh(ele)
        // {
            
        //     $.ajax({
        //       type: "POST",
        //       url: 'http://127.0.0.1/TunisiaWorldCup/php/test.php',
        //       data: { dt: ele.id }
        //     }).done(function( msg ) {
        //         myNavigator.pushPage('clickteama.html');
        //         alert($('#clickteamcontentee').html()); 
        //     });
            // $.ajax({
            //     method: 'POST',
            //     url: 'http://127.0.0.1/TunisiaWorldCup/php/test.php',
            //     dataType: 'text',
            //     data: { dt: ele }
            //     success: function (data) { 
            //         $('#clickteamcontent').html(data); 
            //     }
            // });
            


        // }

