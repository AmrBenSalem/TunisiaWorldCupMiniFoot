// For @onsenui/custom-elements
if (window.customElements) { // even if native CE1 impl exists, use polyfill
    window.customElements.forcePolyfill = true;
}
